#ifndef PROCESS_CALL_H
#define PROCESS_CALL_H

#include "cb_structs.h"
//#include "hardware.h"

void process_call(CallData &call);

#endif

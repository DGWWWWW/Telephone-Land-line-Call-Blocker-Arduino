#include <Arduino.h>
#include <ctype.h>          // <  > tells compiler this is std library
#include <string.h>
#include <EEPROM.h>
#include "main.h"
#include "eeprom25aa512.h"
#include "process_call.h"
#include "hardware.h"
#include "lcd_display.h"

#define STORED_MONTH_ADDR 1

enum CallAction             // how call is handled
{
    CALL_ALLOW,           // do nothing with relays
    CALL_HANGUP,          // go off hook briefly then go on hook
    CALL_VOICEMAIL        // ie: disconnect house from line
};


// ----------------------------------------------------
// Normalize call data
// ----------------------------------------------------
static void normalize_call_data(CallData &call)
{
    // Force null termination
    call.name[15] = '\0';
    call.number[10] = '\0';
    call.date[6] = '\0';
    call.count[2] = '\0';
    call.type[1] = '\0';
    call.duplicate[1] = '\0';

    // Trim trailing spaces from name
    for (int8_t i = 14; i >= 0; i--)
    {
        if (call.name[i] == ' ')
            call.name[i] = '\0';
        else
            break;
    }


    // Normalize caller name to uppercase.
    for (uint8_t i = 0; call.name[i] != '\0'; i++)
    {
        call.name[i] =
            toupper((unsigned char)call.name[i]);
    }


    // Trim trailing spaces from number
    for (int8_t i = 9; i >= 0; i--)
    {
        if (call.number[i] == ' ')
            call.number[i] = '\0';
        else
            break;
    }

    // Trim trailing spaces from date
    for (int8_t i = 5; i >= 0; i--)
    {
        if (call.date[i] == ' ')
            call.date[i] = '\0';
        else
            break;
    }
}


// ----------------------------------------------------
// Print completed call data
// ----------------------------------------------------
static void print_call_data(const CallData &call)
{
    Serial.println();
    Serial.println(F("----- PROCESS CALL -----"));

    Serial.print(F("Name:      "));
    Serial.println(call.name);

    Serial.print(F("Number:    "));
    Serial.println(call.number);

    Serial.print(F("Date:      "));
    Serial.println(call.date);

    Serial.print(F("Count:     "));
    Serial.println(call.count);

    Serial.print(F("Type:      "));
    Serial.println(call.type);

    Serial.print(F("Duplicate: "));
    Serial.println(call.duplicate);

    Serial.println(F("------------------------"));
}


static bool valid_call_data(const CallData &call)
{
    // Must have at least a name or number
    if (call.name[0] == '\0' &&
        call.number[0] == '\0')
    {
        return false;
    }

    // Number, if present, must contain digits only
    for (uint8_t i = 0; call.number[i] != '\0'; i++)
    {
        if (!isdigit(call.number[i]))
            return false;
    }

    // Date, if present, must contain digits only
    for (uint8_t i = 0; call.date[i] != '\0'; i++)
    {
        if (!isdigit(call.date[i]))
            return false;
    }

    return true;
}



static int16_t find_call_record(CallData &call)
{
    CallRecord record;
    CallData storedCall;

    bool partialMatch = false;

    const uint16_t recordCount =
        (MAX_ADDRESS + 1UL) / sizeof(CallRecord);

    // Default: no partial match
    call.duplicate[0] = '0';
    call.duplicate[1] = '\0';

    for (uint16_t i = 0; i < recordCount; i++)
    {
        readRecord(i, record);

        // Ignore empty records
        if (record.type == 'E')
            continue;

        recordToCallData(record, storedCall);
        normalize_call_data(storedCall);

        bool nameMatch =
            (strcmp(call.name, storedCall.name) == 0);

        bool numberMatch =
            (strcmp(call.number, storedCall.number) == 0);

        // Exact match: both name AND number
        if (nameMatch && numberMatch)
        {
            return i;
        }


        // Partial match: exactly one matches
        if (nameMatch != numberMatch)
        {
            partialMatch = true;
        }
    }


    // No exact match was found.
    // Mark incoming record if any partial match was seen.

    if (partialMatch)
    {
        call.duplicate[0] = 'P';
        call.duplicate[1] = '\0';
    }

    return -1;
}




static int16_t find_empty_record()
{
    CallRecord record;

    const uint16_t recordCount =
        (MAX_ADDRESS + 1UL) / sizeof(CallRecord);

    for (uint16_t i = 0; i < recordCount; i++)
    {
        readRecord(i, record);

        if (record.type == 'E')
        {
            return i;
        }
    }

    return -1;
}



static bool is_state_spam(const CallData &call)
{
    size_t len = strlen(call.name);

    // Need at least 4 characters
    if (len < 4)
        return false;

    // Examine last 4 characters:
    // space, space, letter, letter

    if (call.name[len - 4] != ' ')
        return false;

    if (call.name[len - 3] != ' ')
        return false;

    if (!isalpha(call.name[len - 2]))
        return false;

    if (!isalpha(call.name[len - 1]))
        return false;

    return true;
}


static int16_t find_oldest_record()
{
    CallRecord record;
    CallData data;

    int16_t oldestRecord = -1;
    uint32_t oldestDate = 999999UL;

    const uint16_t recordCount =
        (MAX_ADDRESS + 1UL) / sizeof(CallRecord);

    for (uint16_t i = 0; i < recordCount; i++)
    {
        readRecord(i, record);

        // Never automatically replace whitelist or blacklist records.
        // Only unknown records are candidates.
        if (record.type != 'U')
            continue;

        recordToCallData(record, data);

        // Date format is MMDDYY.
        // Convert to YYMMDD so normal numeric comparison works.
        //
        // Example:
        // 082626 -> 260826

        uint32_t dateValue =
            (uint32_t)(data.date[4] - '0') * 100000UL +
            (uint32_t)(data.date[5] - '0') * 10000UL +
            (uint32_t)(data.date[0] - '0') * 1000UL +
            (uint32_t)(data.date[1] - '0') * 100UL +
            (uint32_t)(data.date[2] - '0') * 10UL +
            (uint32_t)(data.date[3] - '0');

        if (dateValue < oldestDate)
        {
            oldestDate = dateValue;
            oldestRecord = i;
        }
    }

    return oldestRecord;
}


static bool replace_oldest_record(CallData &call)
{
    int16_t recordNumber = find_oldest_record();

    if (recordNumber < 0)
    {
        return false;
    }

    CallRecord record;

    // New caller is initially unknown.
    call.type[0] = 'U';
    call.type[1] = '\0';

    callDataToRecord(call, record);

    writeRecord(recordNumber, record);

    Serial.print(F("REPLACED RECORD: "));
    Serial.println(recordNumber);

    return true;
}



static void update_existing_record(int16_t recordNumber, CallData &call)
{
    CallRecord record;

    // Read existing EEPROM record
    readRecord(recordNumber, record);

    // Update last-call date
    memcpy(record.date, call.date, sizeof(record.date));

    // Convert ASCII count to a number
    uint8_t count = 0;

    if (isdigit(record.count[0]) && isdigit(record.count[1]))
    {
        count =
            (record.count[0] - '0') * 10 +
            (record.count[1] - '0');
    }

    // Increment, but never roll past 99
    if (count < 99)
    {
        count++;
    }




   // Convert back to two ASCII characters
    record.count[0] = '0' + (count / 10);
    record.count[1] = '0' + (count % 10);

    // Keep the RAM copy synchronized for the LCD.
    call.count[0] = record.count[0];
    call.count[1] = record.count[1];
    call.count[2] = '\0';

    // Write updated record back to same location
    writeRecord(recordNumber, record);  





    Serial.print(F("RECORD UPDATED - DATE: "));
    Serial.print(call.date);

    Serial.print(F("  COUNT: "));
    Serial.print(record.count[0]);
    Serial.println(record.count[1]);
}



//determine call action
static CallAction determine_call_action(CallData &call, int16_t recordNumber)   // CallAction is the enum at the top
{
    if (recordNumber >= 0)
    {
        Serial.print(F("MATCH FOUND - RECORD: "));
        Serial.println(recordNumber);

        CallRecord record;
        readRecord(recordNumber, record);

        update_existing_record(recordNumber, call);

        // Whitelist has highest priority
        if (record.type == 'W')
        {
            Serial.println(F("WHITELIST - ALLOW CALL"));
            return CALL_ALLOW;
        }

        if (record.type == 'B')
        {
            Serial.println(F("BLACKLIST - HANG UP"));
            return CALL_HANGUP;
        }

        // Existing unknown caller may still be state-style spam
        if (is_state_spam(call))
        {
            Serial.println(F("STATE SPAM - HANG UP"));
            return CALL_HANGUP;
        }

        Serial.println(F("UNKNOWN CALL - SEND TO VOICEMAIL"));
        return CALL_VOICEMAIL;
    }


    // ------------------------------------------------
    // No existing record found - New Caller
    // ------------------------------------------------

    Serial.println(F("NO MATCH FOUND"));

    // Check state-style spam BEFORE storing new caller
    if (is_state_spam(call))
    {
        Serial.println(F("STATE SPAM - HANG UP"));
        return CALL_HANGUP;
    }


    // ------------------------------------------------
    // Store new normal caller
    // ------------------------------------------------

    int16_t emptyRecord = find_empty_record();

    if (emptyRecord >= 0)
    {
        CallRecord record;

        call.type[0] = 'U';
        call.type[1] = '\0';

        callDataToRecord(call, record);
        writeRecord(emptyRecord, record);

        Serial.print(F("NEW CALL STORED IN RECORD "));
        Serial.println(emptyRecord);

        return CALL_VOICEMAIL;
    }

    // ------------------------------------------------
    // EEPROM full
    // ------------------------------------------------
    // ------------------------------------------------
// EEPROM full
// Replace oldest U record
// W and B records are protected
// ------------------------------------------------

    Serial.println(F("EEPROM FULL"));

    if (replace_oldest_record(call))
    {
        Serial.println(F("OLDEST UNKNOWN RECORD REPLACED"));

        return CALL_VOICEMAIL;
    }

    Serial.println(F("ERROR: NO REPLACEABLE RECORD"));

    // EEPROM contains no U records.
    // Latch the dedicated red fault LED and allow the current call.
    digitalWrite(RED_LED_PIN, HIGH);
     digitalWrite(GRN_LED_PIN, LOW);

    return CALL_ALLOW;  

}


static void wait_with_lcd_update(unsigned long duration)
{
    unsigned long startTime = millis();

    while ((unsigned long)(millis() - startTime) < duration)
    {
        lcdDisplayUpdate();
        delay(10);
    }
}

// Both LED elements were verified active HIGH by the setup lamp test.
static void set_call_led(bool red, bool green)
{
    digitalWrite(RED_LED_PIN, red ? HIGH : LOW);
    digitalWrite(GRN_LED_PIN, green ? HIGH : LOW);
}


static void allow_call()
{
    Serial.println(F("ACTION: ALLOW"));
    lcdDisplayAllow();

    digitalWrite(HANGUP_CALL_PIN, LOW);
    digitalWrite(DISCON_REL_PIN, LOW);

    set_call_led(false, true); // green: allowed

    // Allow indicator LED on for 4 seconds
    wait_with_lcd_update(4000UL);

    set_call_led(false, false);

    Serial.println(F("ALLOW COMPLETE"));
}


static void hangup_call()
{
    Serial.println(F("ACTION: HANG UP"));
    lcdDisplayHangup();

    digitalWrite(DISCON_REL_PIN, LOW);

    digitalWrite(HANGUP_CALL_PIN, HIGH);
    set_call_led(true, false); // red: hang up

    // Hold hangup relay active for 3 seconds
    wait_with_lcd_update(3000UL);

    digitalWrite(HANGUP_CALL_PIN, LOW);
    set_call_led(false, false);

    Serial.println(F("HANG UP COMPLETE"));
}


static void voicemail_call()
{
    Serial.println(F("ACTION: VOICEMAIL"));
    lcdDisplayVoicemail();

    digitalWrite(HANGUP_CALL_PIN, LOW);

    digitalWrite(DISCON_REL_PIN, HIGH);
    set_call_led(true, true); // yellow: both LED elements

    // Hold house phones disconnected long enough
    // for incoming call to roll to voicemail.
    wait_with_lcd_update(35000UL);

    digitalWrite(DISCON_REL_PIN, LOW);
    set_call_led(false, false);

    Serial.println(F("VOICEMAIL COMPLETE"));
}



// ----------------------------------------------------
// Apply stored year and detect December-to-January rollover
// ----------------------------------------------------
static void update_call_year(CallData &call)
{
    // Caller ID must supply at least MMDD.
    if (!isdigit(call.date[0]) ||
        !isdigit(call.date[1]) ||
        !isdigit(call.date[2]) ||
        !isdigit(call.date[3]))
    {
        Serial.println(F("ERR: invalid incoming call date"));
        return;
    }

    uint8_t currentMonth =
        (call.date[0] - '0') * 10 +
        (call.date[1] - '0');

    if (currentMonth < 1 || currentMonth > 12)
    {
        Serial.println(F("ERR: invalid incoming call month"));
        return;
    }

    uint8_t previousMonth = EEPROM.read(STORED_MONTH_ADDR);

    // Increment the year only when the month changes
    // from December to January.
    if (currentMonth == 1 && previousMonth == 12)
    {
        if (Stored_year < 99)
            Stored_year++;
        else
            Stored_year = 0;

        EEPROM.update(STORED_YEAR_ADDR, Stored_year);

        Serial.print(F("YEAR ADVANCED TO "));
        Serial.println(Stored_year);
    }

    // Always store the most recently received month.
    EEPROM.update(STORED_MONTH_ADDR, currentMonth);

    // Add the stored two-digit year to the incoming MMDD date.
    if (Stored_year <= 99)
    {
        call.date[4] = '0' + (Stored_year / 10);
        call.date[5] = '0' + (Stored_year % 10);
        call.date[6] = '\0';
    }
    else
    {
        Serial.println(F("ERR: STORED YEAR NOT SET"));
    }
}





// ----------------------------------------------------
// Main call processor
// ----------------------------------------------------
void process_call(CallData &call)
{
    update_call_year(call);

    normalize_call_data(call);

    print_call_data(call);

    int16_t recordNumber =
        find_call_record(call);

    CallAction callAction =
        determine_call_action(call, recordNumber);

    lcdDisplayCall(call);

    switch (callAction)
    {
        case CALL_ALLOW:
            allow_call();
            break;

        case CALL_HANGUP:
            hangup_call();
            break;

        case CALL_VOICEMAIL:
            voicemail_call();
            break;
    }
}


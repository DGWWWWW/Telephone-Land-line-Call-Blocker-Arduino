#include <Arduino.h>
#include <SPI.h>

#include "hardware.h"
#include "eeprom25aa512.h"

// 25AA512 commands
#define EEPROM_READ   0x03
#define EEPROM_WRITE  0x02
#define EEPROM_WREN   0x06
#define EEPROM_RDSR   0x05

/*
usage
writeRecord(12, record);
readRecord(12, record);
*/

void eepromBegin()
{
    pinMode(EEPROM_CS_PIN, OUTPUT);
    digitalWrite(EEPROM_CS_PIN, HIGH);

    SPI.begin();
}


void eepromWriteEnable()
{
    digitalWrite(EEPROM_CS_PIN, LOW);

    SPI.transfer(EEPROM_WREN);

    digitalWrite(EEPROM_CS_PIN, HIGH);
}


void eepromWaitReady()
{
    uint8_t status;

    do {
        digitalWrite(EEPROM_CS_PIN, LOW);

        SPI.transfer(EEPROM_RDSR);
        status = SPI.transfer(0);

        digitalWrite(EEPROM_CS_PIN, HIGH);

    } while (status & 0x01);
}


void readRecord(uint16_t recordNumber,
                CallRecord &record)
{
    uint16_t address =
        (uint32_t)recordNumber * sizeof(CallRecord);

    digitalWrite(EEPROM_CS_PIN, LOW);

    SPI.transfer(EEPROM_READ);
    SPI.transfer(highByte(address));
    SPI.transfer(lowByte(address));

    uint8_t *p = (uint8_t *)&record;

    for (uint8_t i = 0;
         i < sizeof(CallRecord);
         i++) {

        p[i] = SPI.transfer(0);
    }

    digitalWrite(EEPROM_CS_PIN, HIGH);
}


void eepromWriteBytes(uint16_t address,
                      const uint8_t *data,
                      uint16_t length)
{
    while (length > 0) {

        uint16_t pageOffset =
            address % EEPROM_PAGE_SIZE;

        uint16_t bytesToWrite =
            EEPROM_PAGE_SIZE - pageOffset;

        if (bytesToWrite > length)
            bytesToWrite = length;

        eepromWriteEnable();

        digitalWrite(EEPROM_CS_PIN, LOW);

        SPI.transfer(EEPROM_WRITE);
        SPI.transfer(highByte(address));
        SPI.transfer(lowByte(address));

        for (uint16_t i = 0;
             i < bytesToWrite;
             i++) {

            SPI.transfer(data[i]);
        }

        digitalWrite(EEPROM_CS_PIN, HIGH);

        eepromWaitReady();

        address += bytesToWrite;
        data    += bytesToWrite;
        length  -= bytesToWrite;
    }
}


void writeRecord(uint16_t recordNumber,
                 const CallRecord &record)
{
    uint16_t address =
        (uint32_t)recordNumber * sizeof(CallRecord);

    eepromWriteBytes(
        address,
        (const uint8_t *)&record,
        sizeof(CallRecord));
}

uint8_t eepromReadStatus()
{
    digitalWrite(EEPROM_CS_PIN, LOW);

    SPI.transfer(EEPROM_RDSR);
    uint8_t status = SPI.transfer(0);

    digitalWrite(EEPROM_CS_PIN, HIGH);

    return status;
}

void formatEEPROM()
{
    if (eepromReadStatus() == 0xFF) {
        Serial.println(F("ERROR: EEPROM not responding; format aborted"));
        return;
    }
    CallRecord record;

    // Start with an empty record filled with spaces
    memset(&record, ' ', sizeof(CallRecord));

    // Mark record as Empty
    record.type = 'E';

    // Number of complete 35-byte records that fit in EEPROM
    const uint16_t recordCount =
        (MAX_ADDRESS + 1UL) / sizeof(CallRecord);

    Serial.println(F("Formatting EEPROM..."));

    for (uint16_t recordNumber = 0;
         recordNumber < recordCount;
         recordNumber++)
    {
        writeRecord(recordNumber, record);
        CallRecord check;
        readRecord(recordNumber, check);
        if (memcmp(&record, &check, sizeof(record)) != 0) {
            Serial.print(F("ERROR: EEPROM verify failed at record "));
            Serial.println(recordNumber);
            Serial.println(F("Format incomplete; check EEPROM wiring"));
            return;
        }
    }

    Serial.print(F("Records formatted: "));
    Serial.println(recordCount);

    Serial.println(F("EEPROM format complete"));

    // Formatting creates empty records, so the full-memory error LED is cleared.
    digitalWrite(RED_LED_PIN, LOW);
    digitalWrite(GRN_LED_PIN, LOW);   
}


uint8_t eepromReadByte(uint16_t address)
{
    digitalWrite(EEPROM_CS_PIN, LOW);

    SPI.transfer(EEPROM_READ);
    SPI.transfer(highByte(address));
    SPI.transfer(lowByte(address));

    uint8_t value = SPI.transfer(0);

    digitalWrite(EEPROM_CS_PIN, HIGH);

    return value;
}


void eepromWriteByte(uint16_t address, uint8_t value)
{
    eepromWriteBytes(address, &value, 1);
}

uint8_t readEEPROMByte(uint16_t address)
{
    digitalWrite(EEPROM_CS_PIN, LOW);

    SPI.transfer(EEPROM_READ);
    SPI.transfer(highByte(address));
    SPI.transfer(lowByte(address));

    uint8_t value = SPI.transfer(0);

    digitalWrite(EEPROM_CS_PIN, HIGH);

    return value;
}

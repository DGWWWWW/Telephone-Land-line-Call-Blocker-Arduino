#ifndef EEPROM_25AA512_H
#define EEPROM_25AA512_H

#include <Arduino.h>
#include "cb_structs.h"

// EEPROM characteristics
#define EEPROM_PAGE_SIZE 128
#define MAX_ADDRESS 65535UL   //65K bytes of 8 bits each

#define YEAR_ADDRESS  0

uint8_t readEEPROMByte(uint16_t address);

void writeEEPROMByte(uint16_t address, uint8_t value);

// Public functions
void eepromBegin();

uint8_t eepromReadStatus();
void eepromWriteEnable();
void eepromWaitReady();
void formatEEPROM();

uint8_t eepromReadByte(uint16_t address);
void eepromWriteByte(uint16_t address, uint8_t value);


void readRecord(uint16_t recordNumber,
                CallRecord &record);

void writeRecord(uint16_t recordNumber,
                 const CallRecord &record);

#endif
#ifndef UTILITY_H
#define UTILITY_H

#include <Arduino.h>
#include "cb_structs.h"

void makeFakeCall(CallData &call);
void printCallData(const CallData &call);

void parseCallData(const char *name, const char *number, CallData &call);


#endif

/*
CALL BLOCKER VERSION 3 BETA - ATMEGA328/328P PORT
PORTED FROM THE ARDUINO MEGA 2560 BETA RELEASED 8-29-26.
9-9-26 Comments added about changing g,y,r leds to bicolor type on D2 and D4 but
keep relay functions D4 (off hook / hangup) and D5 (discon/voicemail)  as they are now.
10-3-26 menu edit timeout added

*/
#include <Arduino.h>
#include <EEPROM.h>
#include "main.h"
#include "hardware.h"
#include "eeprom25aa512.h"
#include "callerid.h"
#include "c_serial.h"
#include "lcd_display.h"

bool USE_FAKE_DATA = false;   //fake data flag
uint8_t Stored_year = 0;
#define STORED_YEAR_ADDR  0

//=====================================================
void setup()
{
    pinMode(RED_LED_PIN, OUTPUT);
    pinMode(HANGUP_CALL_PIN, OUTPUT);
    pinMode(DISCON_REL_PIN, OUTPUT);
    pinMode(GRN_LED_PIN, OUTPUT);
    pinMode(CDET_PIN, INPUT);


    digitalWrite(RED_LED_PIN, HIGH);    // ON
    digitalWrite(GRN_LED_PIN, HIGH);    // On
    delay(1000);
    digitalWrite(RED_LED_PIN, LOW);     // Off
    digitalWrite(GRN_LED_PIN, LOW);     // Off

    //Serial.begin(9600);
    c_serial_begin();
    eepromBegin();
    callerIDBegin();
    lcdDisplayBegin();
      
  Serial.println(F("***** Start CB3 *****"));
  
// All actions inactive initially
digitalWrite(HANGUP_CALL_PIN, LOW);     // this is to drive a relay. Red
digitalWrite(DISCON_REL_PIN, LOW);  // this is to drive a relay.  Yellow
digitalWrite(RED_LED_PIN, LOW);
digitalWrite(GRN_LED_PIN, LOW);    

  Stored_year = EEPROM.read(STORED_YEAR_ADDR);

  Serial.print(F("Stored year = "));
  Serial.println(Stored_year);
  
}

//============================================================
void loop()
{
    lcdDisplayUpdate();
    check_c_serial();

    if (!lcdMenuActive())
        testCallerID();
}
//=============================

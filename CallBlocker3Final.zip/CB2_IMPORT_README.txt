CB2 to CB3 one-time import

Upload this complete main folder as an Arduino sketch. With the external 25AA512 connected and already formatted, open Serial Monitor at 9600 baud and send IMP. Use LST to inspect all imported records, or DIS,<record number> for individual records. Do not send FMT if CB3 already has records you want to keep.

IMP adds the 30 supplied W/B records into the first empty EEPROM slots, skipping a phone number already stored in CB3. It preserves existing CB3 records, converts CB2 dates from YYMMDD to MMDDYY, initializes count to 00 and duplicate to 0, and reads back every new record to verify the write. It preserves [V] as part of the original name. The CB2 dump did not contain counts, so they cannot be recovered. Running IMP again skips all existing numbers.

The source addresses (1, 65, etc.) are CB2 addresses, not CB3 record numbers. The original code files are otherwise unchanged except for the IMP command hookup in c_serial.cpp.

#ifndef HARDWARE_H
#define HARDWARE_H

#include <Arduino.h>

// Hardware SPI pins are selected automatically by SPI library:
// ATmega328P:
//   MISO = D12, physical pin 18
//   MOSI = D11, physical pin 17
//   SCK  = D13, physical pin 19
//--------------------------------------------------
#define CLI_PWDN_PIN        9   // HT9032 power-down control          328 pin-15 YEL 
#define HANGUP_CALL_PIN     10  // off hook relay                     328 pin-16 BLU
#define DISCON_REL_PIN      17  // disconnect house relay             328 pin-26 GRN
#define CDET_PIN            16  // carrier detect                     328 pin-25 WHT 3
#define CALLER_ID_RX        6   // HT9032 DOUT                        328 pin-12 WHT 15
#define CALLER_ID_TX        7   // SoftwareSerial TX; DONT USE        328 pin-13 nc
#define EEPROM_CS_PIN       8   // EEPROM chip select                 328:pin-14 
#define GRN_LED_PIN         4   // ATmega328: Grn LED pin 6
#define RED_LED_PIN         3   // ATmega328: Red LED pin 5

#define LCD_BUTTONS_PIN   A0    //   328 pin-23 analog buttons, pullup to 10k
#define RING_DET_PIN      A1    //   328 pin-24 ring det analog signal WHT 9

#endif

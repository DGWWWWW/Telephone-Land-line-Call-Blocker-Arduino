#ifndef CB_STRUCTS_H
#define CB_STRUCTS_H

#include <Arduino.h>

struct CallData {
  char name[16];
  char number[11];
  char date[7];
  char count[3];
  char type[2];
  char duplicate[2];
};

struct CallRecord {             // no null since this is data to/from memory which has no nulls stored
    char name[15];
    char number[10];
    char date[6];
    char count[2];
    char type;
    char duplicate;
};

static_assert(sizeof(CallRecord) == 35,
              "CallRecord must be exactly 35 bytes");   // this text must be what gets reported if other than 35 attempted.

void callDataToRecord(const CallData &data,
                      CallRecord &record);

void recordToCallData(const CallRecord &record,
                      CallData &data);

#endif

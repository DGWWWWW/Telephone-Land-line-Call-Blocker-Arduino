#include <Arduino.h>
#include <string.h>

#include "utility.h"

void parseCallData(const char *name, const char *number, CallData &call)
{
    strncpy(call.name, name, sizeof(call.name) - 1);
    call.name[sizeof(call.name) - 1] = '\0';
    strncpy(call.number, number, sizeof(call.number) - 1);
    call.number[sizeof(call.number) - 1] = '\0';
    strcpy(call.date, "000000");
    strcpy(call.count, "01");
    strcpy(call.type, "U");
    strcpy(call.duplicate, "N");
}

void makeFakeCall(CallData &call)
{
    strcpy(call.name,      "WILLOW GROVE PA");      //:WILLOW GROVE PA  NUM:2157068342  
    strcpy(call.number,    "2157068342");
    strcpy(call.date,      "092926");
    strcpy(call.count,     "01");
    strcpy(call.type,      "U");
    strcpy(call.duplicate, "N");
}

void printCallData(const CallData &call)
{
    Serial.println(F("----- CALL DATA -----"));
    Serial.print(F("Name:      "));
    Serial.println(call.name);
    Serial.print(F("Number:    "));
    Serial.println(call.number);
    Serial.print(F("Date:      "));
    Serial.println(call.date);
    Serial.print(F("Count:     "));
    Serial.println(call.count);
    Serial.print(F("Type:      "));
    Serial.println(call.type);
    Serial.print(F("Duplicate: "));
    Serial.println(call.duplicate);
    Serial.println(F("---------------------"));
}

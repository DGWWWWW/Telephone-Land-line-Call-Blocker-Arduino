#include <Arduino.h>
#include <Wire.h>
#include <hd44780.h>
#include <hd44780ioClass/hd44780_I2Cexp.h>

#include "lcd_display.h"
#include "hardware.h"
#include "eeprom25aa512.h"

static const uint8_t LCD_COLUMNS = 20;
static const uint8_t LCD_ROWS = 4;
static const unsigned long STARTUP_BACKLIGHT_MS = 5000UL;
static const unsigned long CALL_BACKLIGHT_MS = 15000UL;
static const unsigned long MENU_IDLE_TIMEOUT_MS = 60000UL;

static hd44780_I2Cexp lcd;
static bool lcdReady = false;
static bool backlightIsOn = false;
static unsigned long backlightStartTime = 0;
static unsigned long backlightOnTime = 0;

enum MenuState
{
    MENU_IDLE,
    MENU_RECORDS,
    MENU_EDIT
};

enum LcdButton
{
    BUTTON_NONE,
    BUTTON_RIGHT,
    BUTTON_UP,
    BUTTON_DOWN,
    BUTTON_LEFT,
    BUTTON_SELECT
};

static MenuState menuState = MENU_IDLE;
static unsigned long lastMenuButtonTime = 0;
static uint16_t currentRecordNumber = 0;
static CallRecord currentRecord;
static char editedType = 'U';

static LcdButton lastRawButton = BUTTON_NONE;
static LcdButton stableButton = BUTTON_NONE;
static unsigned long buttonChangeTime = 0;

static const unsigned long BUTTON_DEBOUNCE_MS = 25UL;
static const uint16_t RECORD_COUNT =
    (MAX_ADDRESS + 1UL) / sizeof(CallRecord);

static void startBacklightTimer(unsigned long duration)
{
    if (!lcdReady)
        return;

    lcd.backlight();
    backlightIsOn = true;
    backlightStartTime = millis();
    backlightOnTime = duration;
}

static void clearLine(uint8_t row)
{
    lcd.setCursor(0, row);
    lcd.print(F("                    "));
    lcd.setCursor(0, row);
}

static LcdButton readButton()
{
    int value = analogRead(LCD_BUTTONS_PIN);

    if (value > 950) return BUTTON_NONE;
    if (value < 100) return BUTTON_RIGHT;
    if (value < 300) return BUTTON_UP;
    if (value < 500) return BUTTON_DOWN;
    if (value < 700) return BUTTON_LEFT;
    if (value < 900) return BUTTON_SELECT;

    return BUTTON_NONE;
}

static void displayRecord(bool editing, bool saved = false)
{
    CallData data;
    recordToCallData(currentRecord, data);

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(data.name);

    lcd.setCursor(0, 1);
    lcd.print(data.number);
    lcd.setCursor(15, 1);
    lcd.print(F("DUP:"));
    lcd.print(data.duplicate[0]);

    lcd.setCursor(0, 2);
    lcd.print(F("REC:"));
    lcd.print(currentRecordNumber);
    lcd.setCursor(9, 2);
    lcd.print(F("DATE:"));
    lcd.print(data.date);

    clearLine(3);
    lcd.print(F("TYPE:"));
    lcd.print(editing ? editedType : currentRecord.type);

    if (saved)
    {
        lcd.print(F("  SAVED"));
    }
    else if (editing)
    {
        lcd.print(F(" U/D  S:SAVE"));
    }
    else
    {
        lcd.print(F(" CNT:"));
        lcd.print(data.count);
        lcd.print(F(" R:EDIT"));
    }
}

static bool loadRecord(uint16_t recordNumber)
{
    readRecord(recordNumber, currentRecord);

    if (currentRecord.type == 'E')
        return false;

    currentRecordNumber = recordNumber;
    editedType = currentRecord.type;
    return true;
}

static bool findFirstRecord()
{
    for (uint16_t recordNumber = 0;
         recordNumber < RECORD_COUNT;
         recordNumber++)
    {
        if (loadRecord(recordNumber))
            return true;
    }

    return false;
}

static bool findNextRecord(bool forward)
{
    uint16_t recordNumber = currentRecordNumber;

    // Search one complete circuit, skipping empty records.
    // Including the starting slot keeps a single-record list usable.
    for (uint16_t checked = 0; checked < RECORD_COUNT; checked++)
    {
        if (forward)
        {
            recordNumber = (recordNumber + 1 >= RECORD_COUNT)
                ? 0 : recordNumber + 1;
        }
        else
        {
            recordNumber = (recordNumber == 0)
                ? RECORD_COUNT - 1 : recordNumber - 1;
        }

        if (loadRecord(recordNumber))
            return true;
    }

    return false;
}

static void displayNoRecords()
{
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(F("NO RECORDS FOUND"));
    lcd.setCursor(0, 2);
    lcd.print(F("LEFT: EXIT"));
}

static void cycleEditedType()
{
    switch (editedType)
    {
        case 'U': editedType = 'B'; break;
        case 'B': editedType = 'W'; break;
        case 'W': editedType = 'E'; break;
        default:  editedType = 'U'; break;
    }
}

static void processButton(LcdButton button)
{
    lastMenuButtonTime = millis();
    // Keep the menu illuminated for the full inactivity period.
    startBacklightTimer((menuState != MENU_IDLE || button == BUTTON_RIGHT)
        ? MENU_IDLE_TIMEOUT_MS : CALL_BACKLIGHT_MS);

    if (menuState == MENU_IDLE)
    {
        if (button == BUTTON_RIGHT)
        {
            menuState = MENU_RECORDS;

            if (findFirstRecord())
                displayRecord(false);
            else
                displayNoRecords();
        }

        return;
    }

    if (menuState == MENU_RECORDS)
    {
        if (button == BUTTON_LEFT)
        {
            menuState = MENU_IDLE;
            lcd.clear();
            lcd.setCursor(0, 0);
            lcd.print(F("MENU EXITED"));
        }
        else if (button == BUTTON_UP)
        {
            if (findNextRecord(false))
                displayRecord(false);
        }
        else if (button == BUTTON_DOWN)
        {
            if (findNextRecord(true))
                displayRecord(false);
        }
        else if (button == BUTTON_RIGHT && currentRecord.type != 'E')
        {
            editedType = currentRecord.type;
            menuState = MENU_EDIT;
            displayRecord(true);
        }

        return;
    }

    if (button == BUTTON_LEFT)
    {
        editedType = currentRecord.type;
        menuState = MENU_RECORDS;
        displayRecord(false);
    }
    else if (button == BUTTON_UP || button == BUTTON_DOWN)
    {
        cycleEditedType();
        displayRecord(true);
    }
    else if (button == BUTTON_SELECT)
    {
        if (editedType == 'E')
        {
            uint16_t clearedRecordNumber = currentRecordNumber;

            memset(&currentRecord, ' ', sizeof(currentRecord));
            currentRecord.type = 'E';
            writeRecord(clearedRecordNumber, currentRecord);

            digitalWrite(RED_LED_PIN, LOW);
            digitalWrite(GRN_LED_PIN, LOW);   
            menuState = MENU_RECORDS;

            currentRecordNumber = clearedRecordNumber;

            if (findNextRecord(true) || findNextRecord(false))
                displayRecord(false);
            else
                displayNoRecords();

            return;
        }

        currentRecord.type = editedType;
        writeRecord(currentRecordNumber, currentRecord);

        if (editedType == 'U')
            digitalWrite(RED_LED_PIN, LOW);
            digitalWrite(GRN_LED_PIN, LOW); 

        menuState = MENU_RECORDS;
        displayRecord(false, true);
    }
}

static void updateButtons()
{
    LcdButton rawButton = readButton();

    if (rawButton != lastRawButton)
    {
        lastRawButton = rawButton;
        buttonChangeTime = millis();
    }

    if (rawButton != stableButton &&
        (unsigned long)(millis() - buttonChangeTime) >= BUTTON_DEBOUNCE_MS)
    {
        stableButton = rawButton;

        if (stableButton != BUTTON_NONE)
            processButton(stableButton);
    }
}

static void showAction(const __FlashStringHelper *action)
{
    if (!lcdReady)
        return;

    clearLine(3);
    lcd.print(F("ACTION: "));
    lcd.print(action);
}

void lcdDisplayBegin()
{
    pinMode(LCD_BUTTONS_PIN, INPUT);

    int status = lcd.begin(LCD_COLUMNS, LCD_ROWS);

    if (status != 0)
    {
        Serial.print(F("LCD INITIALIZATION ERROR: "));
        Serial.println(status);
        return;
    }

    lcdReady = true;
    startBacklightTimer(STARTUP_BACKLIGHT_MS);
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(F("Call Blocker V3.1"));
    lcd.setCursor(0, 1);
    lcd.print(F("System Ready"));
}

void lcdDisplayUpdate()
{
    if (!lcdReady)
        return;

    updateButtons();

    if (menuState != MENU_IDLE &&
        (unsigned long)(millis() - lastMenuButtonTime) >= MENU_IDLE_TIMEOUT_MS)
    {
        // Abandon any unsaved edit and resume normal call handling.
        editedType = currentRecord.type;
        menuState = MENU_IDLE;
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print(F("MENU EXITED"));
        lcd.noBacklight();
        backlightIsOn = false;
    }

    if (backlightIsOn &&
        (unsigned long)(millis() - backlightStartTime) >= backlightOnTime)
    {
        lcd.noBacklight();
        backlightIsOn = false;
    }
}

bool lcdMenuActive()
{
    return menuState != MENU_IDLE;
}

void lcdDisplayCall(const CallData &call)
{
    if (!lcdReady)
        return;

    menuState = MENU_IDLE;
    startBacklightTimer(CALL_BACKLIGHT_MS);
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(call.name);
    lcd.setCursor(0, 1);
    lcd.print(call.number);

    lcd.setCursor(15, 1);
    lcd.print(F("DUP:"));
    lcd.print(call.duplicate[0]);

    lcd.setCursor(0, 2);
    lcd.print(F("DATE:"));
    lcd.print(call.date);
    lcd.print(F(" COUNT:"));
    lcd.print(call.count);
    lcd.setCursor(0, 3);
    lcd.print(F("PROCESSING..."));
}

void lcdDisplayAllow()
{
    showAction(F("ALLOW"));
}

void lcdDisplayHangup()
{
    showAction(F("HANG UP"));
}

void lcdDisplayVoicemail()
{
    showAction(F("VOICEMAIL"));
}

//container for code to handle incoming serial commands with optional argument

#ifndef C_SERIAL_H
#define C_SERIAL_H

#include <Arduino.h>

void c_serial_begin();
void check_c_serial();

#endif
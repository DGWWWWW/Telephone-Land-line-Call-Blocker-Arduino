// #include <Arduino.h>
// #include "callerid.h"
// #include <Arduino.h>
// #include <SoftwareSerial.h>
// #include "hardware.h"


#include <Arduino.h>
#include <SoftwareSerial.h>
#include <string.h>
#include "hardware.h"
#include "process_call.h"
#include "callerid.h"
#include "cb_structs.h"
#include "utility.h"
#include "main.h"

// The ATmega328 has one hardware UART, retained for the command interface.
// HT9032 DOUT uses a separate 1200-baud software receive channel.
static SoftwareSerial callerID(CALLER_ID_RX, CALLER_ID_TX);

#define MDMF_HEADER       0x80
#define MDMF_PARAM_TIME   0x01
#define MDMF_PARAM_CID    0x02
#define MDMF_PARAM_NAME   0x07

enum CID_STATE
{
  CID_IDLE,
  CID_SYNC,
  CID_PACKET,
  CID_MESSAGE,
  CID_END
};

enum CID_MSG_STATE
{
  CIDMSG_HEADER,
  CIDMSG_LEN,
  CIDMSG_DATA
};

CID_STATE cidState = CID_IDLE;
CID_MSG_STATE cidMsgState = CIDMSG_HEADER;

byte tempCount = 0;
byte cidData = 0;
byte packetLen = 0;
byte currLen = 0;

byte msgType = 0;
byte msgLen = 0;
byte msgCurrPos = 0;

char msgData[16];

unsigned long watchdogDelay = 0;
byte watchdogSec = 0;

char cidName[16];
char cidNumber[11];
char cidDate[5];


static bool parseCallerIDMessage(const byte *buf, int count,
                                 char *name, size_t nameSize,
                                 char *number, size_t numberSize)
{
    if (count < 3 || buf[0] != MDMF_HEADER)
        return false;

    const int dataEnd = 2 + buf[1];

    // One checksum byte follows the parameter data.
    if (dataEnd + 1 != count)
        return false;

    name[0] = '\0';
    number[0] = '\0';
    cidDate[0] = '\0';

    int pos = 2;

    while (pos < dataEnd)
    {
        if (pos + 2 > dataEnd)
            return false;

        const byte parameterType = buf[pos++];
        const byte parameterLength = buf[pos++];

        if (pos + parameterLength > dataEnd)
            return false;

        if (parameterType == MDMF_PARAM_TIME && parameterLength >= 4)
        {
            memcpy(cidDate, &buf[pos], 4);
            cidDate[4] = '\0';
        }
        else if (parameterType == MDMF_PARAM_CID)
        {
            size_t copyLength = parameterLength;

            if (copyLength >= numberSize)
                copyLength = numberSize - 1;

            memcpy(number, &buf[pos], copyLength);
            number[copyLength] = '\0';
        }
        else if (parameterType == MDMF_PARAM_NAME)
        {
            size_t copyLength = parameterLength;

            if (copyLength >= nameSize)
                copyLength = nameSize - 1;

            memcpy(name, &buf[pos], copyLength);
            name[copyLength] = '\0';
        }

        pos += parameterLength;
    }

    return cidDate[0] != '\0' &&
           (name[0] != '\0' || number[0] != '\0');
}

bool validCallerID(byte *buf, int count)
{
    for (int i = 0; i < count - 2; i++)
    {
        if (buf[i] == 0x80)
        {
            int dataLength = buf[i + 1];
            int totalLength = dataLength + 3;

            if (i + totalLength > count)
                continue;

            byte sum = 0;

            for (int j = 0; j < totalLength; j++)
                sum += buf[i + j];

            if (sum == 0)
                return true;
        }
    }

    return false;
}

void testCallerID()
{
    if (analogRead(RING_DET_PIN) < 400)
    {
        delay(40);

        if (analogRead(RING_DET_PIN) < 400)
        {
            Serial.println(F("RING DETECTED"));

            CallData call;
            bool callValid = false;

            if (USE_FAKE_DATA)
            {
                makeFakeCall(call); //929

                Serial.println(F("FAKE DATA USED"));

                callValid = true;
            }
            else
            {
                // Real Caller ID
                if (collectCallerID(cidName, sizeof(cidName),
                                    cidNumber, sizeof(cidNumber)))
                {
                    parseCallData(cidName, cidNumber, call);

                    // Caller ID supplies MMDD and time but no year.
                    // process_call() will append the stored year.
                    memcpy(call.date, cidDate, 4);
                    call.date[4] = '0';
                    call.date[5] = '0';
                    call.date[6] = '\0';

                    Serial.println(F("REAL CALLER ID RECEIVED"));

                    callValid = true;
                }
                else
                {
                    Serial.println(F("NO VALID CALLER ID"));
                }
            }

            // From this point forward fake and real calls
            // are handled identically.
            if (callValid)
            {
                process_call(call);
            }

            // Do not process the same ring again
            while (analogRead(RING_DET_PIN) < 400)
            {
            }
        }
    }
}



bool collectCallerID(char *name, size_t nameSize,
                     char *number, size_t numberSize)
{
    // Ring has already been detected and debounced
    // by testCallerID().

    Serial.println(F("Starting Caller ID collection"));

    // Turn on Caller ID decoder
    digitalWrite(CLI_PWDN_PIN, LOW);

    // Discard bytes that arrived before the collection window.
    while (callerID.available())
        callerID.read();

    byte buffer[64];
    uint8_t count = 0;
    uint8_t expectedLength = 0;
    bool receivingMessage = false;

    const unsigned long startTime = millis();

    // Bellcore Caller ID is transmitted between the first and second rings.
    while ((unsigned long)(millis() - startTime) < 8000UL)
    {
        while (callerID.available())
        {
            const byte value = callerID.read();

            if (!receivingMessage)
            {
                // Ignore channel seizure, mark bytes and noise until MDMF.
                if (value == MDMF_HEADER)
                {
                    buffer[0] = value;
                    count = 1;
                    expectedLength = 0;
                    receivingMessage = true;
                }

                continue;
            }

            if (count >= sizeof(buffer))
            {
                receivingMessage = false;
                count = 0;
                expectedLength = 0;
                continue;
            }

            buffer[count++] = value;

            if (count == 2)
            {
                expectedLength = buffer[1] + 3;

                if (expectedLength > sizeof(buffer) || expectedLength < 3)
                {
                    receivingMessage = false;
                    count = 0;
                    expectedLength = 0;
                }

                continue;
            }

            if (expectedLength != 0 && count == expectedLength)
            {
                if (validCallerID(buffer, count) &&
                    parseCallerIDMessage(buffer, count,
                                         name, nameSize,
                                         number, numberSize))
                {
                    Serial.print(F("CALLER ID BYTES CAPTURED: "));
                    Serial.println(count);
                    return true;
                }

                Serial.println(F("INVALID CALLER ID MESSAGE"));
                receivingMessage = false;
                count = 0;
                expectedLength = 0;
            }
        }
    }

    Serial.println(F("CALLER ID TIMEOUT"));
    return false;
}



void callerIDBegin()
{
 
  pinMode(CLI_PWDN_PIN, OUTPUT);
  digitalWrite(CLI_PWDN_PIN, HIGH);   // Decoder powered down initially
  
  Serial.println(F("Holtek Powered Down Initially"));

    // existing ring handling...

  callerID.begin(1200);

  cidState = CID_IDLE;
  cidMsgState = CIDMSG_HEADER;
}

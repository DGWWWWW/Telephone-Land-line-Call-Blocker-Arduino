#include <Arduino.h>
#include <string.h>

#include "cb_structs.h"


void callDataToRecord(const CallData &data,
                      CallRecord &record)
{
    // Fill entire 35-byte EEPROM record with spaces
    memset(&record, ' ', sizeof(record));

    // Copy strings without null terminators
    for (uint8_t i = 0; i < 15 && data.name[i] != '\0'; i++)
        record.name[i] = data.name[i];

    for (uint8_t i = 0; i < 10 && data.number[i] != '\0'; i++)
        record.number[i] = data.number[i];

    for (uint8_t i = 0; i < 6 && data.date[i] != '\0'; i++)
        record.date[i] = data.date[i];

    // Two ASCII count characters
    if (data.count[0] != '\0')
        record.count[0] = data.count[0];

    if (data.count[1] != '\0')
        record.count[1] = data.count[1];

    // Single-character fields
    if (data.type[0] != '\0')
        record.type = data.type[0];

    if (data.duplicate[0] != '\0')
        record.duplicate = data.duplicate[0];
}


void recordToCallData(const CallRecord &record,
                      CallData &data)
{
    memcpy(data.name, record.name, 15);
    data.name[15] = '\0';

    memcpy(data.number, record.number, 10);
    data.number[10] = '\0';

    memcpy(data.date, record.date, 6);
    data.date[6] = '\0';

    // Count is stored as two ASCII characters
    data.count[0] = record.count[0];
    data.count[1] = record.count[1];
    data.count[2] = '\0';

    // Type and duplicate are single characters in EEPROM,
    // but null-terminated strings in CallData.
    data.type[0] = record.type;
    data.type[1] = '\0';

    data.duplicate[0] = record.duplicate;
    data.duplicate[1] = '\0';


    // Remove trailing space padding from variable-length fields

    for (int8_t i = 14; i >= 0; i--)
    {
        if (data.name[i] == ' ')
            data.name[i] = '\0';
        else
            break;
    }

    for (int8_t i = 9; i >= 0; i--)
    {
        if (data.number[i] == ' ')
            data.number[i] = '\0';
        else
            break;
    }

    for (int8_t i = 5; i >= 0; i--)
    {
        if (data.date[i] == ' ')
            data.date[i] = '\0';
        else
            break;
    }
}


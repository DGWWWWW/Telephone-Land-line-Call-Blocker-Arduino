#ifndef CALLERID_H
#define CALLERID_H

#include <Arduino.h>

extern char cidName[16];
extern char cidNumber[11];

void testCallerID();
void callerIDBegin();

bool collectCallerID(char *name, size_t nameSize,
                     char *number, size_t numberSize);

#endif
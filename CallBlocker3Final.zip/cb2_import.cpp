#include <Arduino.h>
#include <avr/pgmspace.h>
#include <string.h>
#include "cb_structs.h"
#include "eeprom25aa512.h"
#include "hardware.h"
#include "cb2_import.h"

// CB2 export: type|name|number|YYMMDD. Stored in flash, not ATmega RAM.
static const char cb2Data[] PROGMEM = R"CB2(
B|TERRACOM LTD|2156078436|260526
W|TRUGREEN|2153155843|260921
W|[V]DON WARE|2154351715|260828
W|OPTHALMIC ASSOC|2153681646|260716
B|PROBABLY FRAUD|2153370982|260206
W|[V]C WARE|2155278905|260830
B|PHILADELPHIA  N|2158971363|260908
W|[V]BRUCE LARRY|6106508240|260918
B|PHILADELPHIA PA|2155151032|260924
W|JEFFERSONHEALTH|2677109844|260614
W|[V]WIRELESS CAL|2672185872|260902
B|FL ST OF|3054438745|260831
W|BUSCHMANN DONNA|6106393045|260528
B|RED STONE LLC|4055621195|260901
B|NORWEGIAN CRUIS|9542336288|260227
B|JOHNSON AND JOH|2153258648|260904
W|[V]BLACK KENNET|2158555847|260811
W|LEACH DAVID|2153531927|260919
W|[V]WILLIAMTRIMA|2153687471|260628
B|FAIRVIEW CEMET|2154490122|260905
B|PCH|8352007459|260714
B|ALORICA|2153159865|260923
B|WILLOW GROVE PA|2157068342|260918
B|PANTUK STEPHEN|2153656058|260821
B|LN LEXINGTON PA|2159964961|260908
B|KATIE ROBY|2153656326|260821
W|GREEN  SEIDNER|2158551054|260925
B|CHILDRENS HOSPI|2155904687|260821
B|MOG INTERNATION|4842233160|260827
B|Call Research|2675260370|260901
)CB2";

static bool findNumber(const char *number, uint16_t &slot, bool &exists)
{
    const uint16_t capacity = (MAX_ADDRESS + 1UL) / sizeof(CallRecord);
    uint16_t firstEmpty = capacity;
    CallRecord r;
    for (uint16_t i = 0; i < capacity; ++i) {
        readRecord(i, r);
        if (r.type == 'E') {
            if (firstEmpty == capacity) firstEmpty = i;
        } else if (memcmp(r.number, number, 10) == 0) {
            slot = i;
            exists = true;
            return true;
        }
    }
    exists = false;
    slot = firstEmpty;
    return firstEmpty < capacity;
}

static bool importLine(char *line, uint8_t &added, uint8_t &skipped)
{
    char *p1 = strchr(line, '|');
    if (!p1) return false;
    *p1++ = 0;
    char *p2 = strchr(p1, '|');
    if (!p2) return false;
    *p2++ = 0;
    char *p3 = strchr(p2, '|');
    if (!p3) return false;
    *p3++ = 0;
    if ((line[0] != 'B' && line[0] != 'W') || line[1] ||
        !*p1 || strlen(p1) > 15 || strlen(p2) != 10 || strlen(p3) != 6)
        return false;
    for (uint8_t i = 0; i < 10; ++i) if (p2[i] < '0' || p2[i] > '9') return false;
    for (uint8_t i = 0; i < 6; ++i) if (p3[i] < '0' || p3[i] > '9') return false;

    uint16_t slot;
    bool exists;
    if (!findNumber(p2, slot, exists)) {
        Serial.println(F("IMPORT STOPPED: EEPROM full"));
        return false;
    }
    if (exists) {
        ++skipped;
        return true; // Preserve any edits already made in CB3.
    }
    CallRecord r;
    memset(&r, ' ', sizeof(r));
    memcpy(r.name, p1, strlen(p1));
    memcpy(r.number, p2, 10);
    // CB2 YYMMDD -> CB3 MMDDYY.
    memcpy(r.date, p3 + 2, 4);
    memcpy(r.date + 4, p3, 2);
    memcpy(r.count, "00", 2); // CB2 dump has no call count.
    r.type = line[0];
    r.duplicate = '0';
    writeRecord(slot, r);
    CallRecord check;
    readRecord(slot, check);
    if (memcmp(&r, &check, sizeof(r)) != 0) {
        Serial.print(F("IMPORT VERIFY FAILED AT RECORD "));
        Serial.println(slot);
        return false;
    }
    ++added;
    Serial.print(F("IMPORTED RECORD "));
    Serial.print(slot);
    Serial.print(F("  "));
    Serial.println(p2);
    return true;
}

void importCB2()
{
    if (eepromReadStatus() == 0xFF) {
        Serial.println(F("ERROR: EEPROM not responding; import aborted"));
        return;
    }
    uint8_t added = 0, skipped = 0;
    char line[48];
    uint8_t used = 0;
    bool ok = true;
    for (size_t pos = 0; pos < sizeof(cb2Data); ++pos) {
        char c = pgm_read_byte(cb2Data + pos);
        if (c == '\0') break;
        if (c == '\r') continue;
        if (c == '\n') {
            if (used) {
                line[used] = '\0';
                if (!importLine(line, added, skipped)) { ok = false; break; }
                used = 0;
            }
        } else if (used < sizeof(line) - 1) {
            line[used++] = c;
        } else {
            ok = false;
            Serial.println(F("IMPORT STOPPED: input line too long"));
            break;
        }
    }
    Serial.print(F("CB2 import: added "));
    Serial.print(added);
    Serial.print(F(", existing numbers skipped "));
    Serial.println(skipped);
    if (!ok) Serial.println(F("IMPORT INCOMPLETE; inspect records with LST"));
}

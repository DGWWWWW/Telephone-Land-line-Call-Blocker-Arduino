#ifndef LCD_DISPLAY_H
#define LCD_DISPLAY_H

#include <Arduino.h>
#include "cb_structs.h"

void lcdDisplayBegin();
void lcdDisplayUpdate();
bool lcdMenuActive();
void lcdDisplayCall(const CallData &call);
void lcdDisplayAllow();
void lcdDisplayHangup();
void lcdDisplayVoicemail();

#endif

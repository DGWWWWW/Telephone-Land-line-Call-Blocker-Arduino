#ifndef MAIN_H
#define MAIN_H

#include <Arduino.h>

#define STORED_YEAR_ADDR  0
#define STORED_MONTH_ADDR 1

extern bool USE_FAKE_DATA;
extern uint8_t Stored_year;

#endif//
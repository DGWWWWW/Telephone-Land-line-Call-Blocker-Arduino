// code container for serial.h

#include <Arduino.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <EEPROM.h>
#include "main.h"
#include "c_serial.h"
#include "hardware.h"
#include "eeprom25aa512.h"
#include "cb2_import.h"


#define SERIAL_BAUD      9600
#define SERIAL_BUF_SIZE  80

static char serialBuf[SERIAL_BUF_SIZE];
static byte serialIndex = 0;

// ----------------------------------------------------
// Internal command processor
// ----------------------------------------------------
static void process_serial_command(char *line)
{
    char *cmd;
    char *argA;
    char *argB;

    // Format:
    // CCC
    // CCC,AAA
    // CCC,AAA,BBB

    cmd  = strtok(line, ",");
    argA = strtok(NULL, ",");
    argB = strtok(NULL, "");

    if (cmd == NULL)
        return;


    // ----------------------------------------
    // Validate command
    // Must be exactly 3 alphabetic characters
    // ----------------------------------------

    if (strlen(cmd) != 3)
    {
        Serial.println(F("ERR: command must be 3 letters"));
        return;
    }

    for (byte i = 0; i < 3; i++)
    {
        if (!isalpha(cmd[i]))
        {
            Serial.println(F("ERR: invalid command"));
            return;
        }

        // Make commands case-insensitive
        cmd[i] = toupper(cmd[i]);
    }


    if (strcmp(cmd, "IMP") == 0) {
        importCB2();
        return;
    }

    // ========================================
    // FMT
    // Format EEPROM
    // ========================================

    if (strcmp(cmd, "FMT") == 0)
    {
        Serial.println(F("FMT received"));

        formatEEPROM();

        return;
    }


    // ========================================
    // YER,26
    // Store current year
    // ========================================

    if (strcmp(cmd, "YER") == 0)
    {
        if (argA == NULL)
        {
            Serial.println(F("ERR: year required"));
            return;
        }

        char *endPtr;
        unsigned long year = strtoul(argA, &endPtr, 10);

        if (*endPtr != '\0')
        {
            Serial.println(F("ERR: invalid year"));
            return;
        }

        if (year > 99)
        {
            Serial.println(F("ERR: year must be 0-99"));
            return;
        }

        Serial.print(F("Stored: Year = "));
        Serial.println(year);

        Stored_year = (uint8_t)year;

        EEPROM.update(STORED_YEAR_ADDR, Stored_year);
    
        return;
    }



// ========================================
// DAT
// Display internal EEPROM date values
// ========================================

if (strcmp(cmd, "DAT") == 0)
{
    uint8_t storedYear =
        EEPROM.read(STORED_YEAR_ADDR);

    uint8_t storedMonth =
        EEPROM.read(STORED_MONTH_ADDR);

    Serial.println(F("----- STORED DATE VALUES -----"));

    Serial.print(F("YEAR:  "));
    if (storedYear <= 99)
        Serial.println(storedYear);
    else
        Serial.println(F("NOT SET"));

    Serial.print(F("MONTH: "));
    if (storedMonth >= 1 && storedMonth <= 12)
        Serial.println(storedMonth);
    else
        Serial.println(F("NOT SET"));

    Serial.println(F("------------------------------"));

    return;
}




    // ========================================
    // WHT,name,number
    //
    // Example:
    // WHT,JOHN SMITH,2155551234
    // ========================================

    if (strcmp(cmd, "WHT") == 0)
    {
        if (argA == NULL || argB == NULL)
        {
            Serial.println(F("ERR: WHT requires name and number"));
            return;
        }

        const size_t nameLength = strlen(argA);

        if (nameLength == 0 || nameLength > 15)
        {
            Serial.println(F("ERR: name must be 1-15 characters"));
            return;
        }

        if (strlen(argB) != 10)
        {
            Serial.println(F("ERR: number must be exactly 10 digits"));
            return;
        }

        for (uint8_t i = 0; i < 10; i++)
        {
            if (!isdigit(argB[i]))
            {
                Serial.println(F("ERR: number must contain digits only"));
                return;
            }
        }

        const uint16_t recordCount =
            (MAX_ADDRESS + 1UL) / sizeof(CallRecord);

        int16_t existingRecord = -1;
        int16_t emptyRecord = -1;
        CallRecord record;

        for (uint16_t i = 0; i < recordCount; i++)
        {
            readRecord(i, record);

            if (record.type == 'E')
            {
                if (emptyRecord < 0)
                    emptyRecord = i;

                continue;
            }

            if (memcmp(record.number, argB, sizeof(record.number)) == 0)
            {
                existingRecord = i;
                break;
            }
        }

        if (existingRecord >= 0)
        {
            readRecord(existingRecord, record);

            memset(record.name, ' ', sizeof(record.name));
            memcpy(record.name, argA, nameLength);

            memcpy(record.date, "000000", sizeof(record.date));
            memcpy(record.count, "00", sizeof(record.count));

            record.type = 'W';
            record.duplicate = '0';
            // memset(record.name, ' ', sizeof(record.name));
            // memcpy(record.name, argA, nameLength);
            // record.type = 'W';

            writeRecord(existingRecord, record);

            Serial.print(F("EXISTING RECORD SET TO WHITELIST: "));
            Serial.println(existingRecord);
            return;
        }

        if (emptyRecord < 0)
        {
            Serial.println(F("ERR: EEPROM FULL - WHITELIST NOT ADDED"));
            return;
        }

        memset(&record, ' ', sizeof(record));
        memcpy(record.name, argA, nameLength);
        memcpy(record.number, argB, sizeof(record.number));
        memcpy(record.date, "000000", sizeof(record.date));
        memcpy(record.count, "00", sizeof(record.count));
        record.type = 'W';
        record.duplicate = '0';

        writeRecord(emptyRecord, record);

        Serial.print(F("WHITELIST RECORD ADDED: "));
        Serial.println(emptyRecord);
        return;
    }


    // ========================================
// ENM,record,name
//
// Example:
// ENM,0,TEST  PA
// ========================================

if (strcmp(cmd, "ENM") == 0)
{
    if (argA == NULL || argB == NULL)
    {
        Serial.println(F("ERR: ENM requires record and name"));
        return;
    }

    char *endPtr;
    unsigned long recordNumber = strtoul(argA, &endPtr, 10);

    if (*endPtr != '\0')
    {
        Serial.println(F("ERR: invalid record number"));
        return;
    }

    const uint16_t recordCount =
        (MAX_ADDRESS + 1UL) / sizeof(CallRecord);

    if (recordNumber >= recordCount)
    {
        Serial.println(F("ERR: record number out of range"));
        return;
    }

    if (strlen(argB) > 15)
    {
        Serial.println(F("ERR: name too long"));
        return;
    }

    CallRecord record;

    readRecord((uint16_t)recordNumber, record);

    if (record.type == 'E')
    {
        Serial.println(F("ERR: record is empty"));
        return;
    }

    // Clear existing fixed-width name field
    memset(record.name, ' ', sizeof(record.name));

    // Copy new name, without a null terminator
    memcpy(record.name, argB, strlen(argB));

    writeRecord((uint16_t)recordNumber, record);

    Serial.print(F("RECORD "));
    Serial.print(recordNumber);
    Serial.print(F(" NAME SET TO "));
    Serial.println(argB);

    return;
}


    //============================
    // blink LED once
    //=============================
    if (strcmp(cmd, "BNK") == 0)        //928
    {
            Serial.println(F("Blink LED"));
            digitalWrite(RED_LED_PIN, HIGH);   // ON
            digitalWrite(GRN_LED_PIN, HIGH);    // On
            Serial.println(F("LED ON"));
            delay(1000);
            digitalWrite(RED_LED_PIN, LOW);    // OFF
             digitalWrite(GRN_LED_PIN, LOW);    // OFF
            Serial.println(F("LED OFF"));
            delay(1000);                   // remain OFF for 1 second
        return;
    }



// ========================================
// TYP,record,type
//
// Examples:
// TYP,0,W
// TYP,0,B
// TYP,0,U
// ========================================

if (strcmp(cmd, "TYP") == 0)
{
    if (argA == NULL || argB == NULL)
    {
        Serial.println(F("ERR: TYP requires record and type"));
        return;
    }

    // -----------------------------
    // Get record number
    // -----------------------------
    char *endPtr;
    unsigned long recordNumber = strtoul(argA, &endPtr, 10);

    if (*endPtr != '\0')
    {
        Serial.println(F("ERR: invalid record number"));
        return;
    }

    // Number of complete records in EEPROM
    const uint16_t recordCount =
        (MAX_ADDRESS + 1UL) / sizeof(CallRecord);

    if (recordNumber >= recordCount)
    {
        Serial.println(F("ERR: record number out of range"));
        return;
    }

    // -----------------------------
    // Validate type
    // -----------------------------
    char newType = toupper(argB[0]);

    if (argB[1] != '\0')
    {
        Serial.println(F("ERR: type must be one character"));
        return;
    }

    if (newType != 'W' &&
    newType != 'B' &&
    newType != 'U' &&
    newType != 'E')
{
    Serial.println(F("ERR: type must be W, B, U, or E"));
    return;
}

    // -----------------------------
    // Read, change, write record
    // -----------------------------
    CallRecord record;

   readRecord((uint16_t)recordNumber, record);

if (newType == 'E')
{
    // Completely clear the record.
    memset(&record, ' ', sizeof(record));
    record.type = 'E';
}
else
{
    // An empty record cannot be changed to W, B, or U.
    if (record.type == 'E')
    {
        Serial.println(F("ERR: record is empty"));
        return;
    }

    record.type = newType;
}

// Write either the cleared record or the changed type.
writeRecord((uint16_t)recordNumber, record);

// E provides empty space; U provides a replaceable record.
if (newType == 'E' || newType == 'U')
{
    digitalWrite(RED_LED_PIN, LOW);
     digitalWrite(GRN_LED_PIN, LOW);  
}

Serial.print(F("RECORD "));
Serial.print(recordNumber);

if (newType == 'E')
{
    Serial.println(F(" CLEARED"));
}
else
{
    Serial.print(F(" TYPE SET TO "));
    Serial.println(newType);
}

return;
}


// ========================================
// DIS,record
//
// Example:
// DIS,0
// ========================================

if (strcmp(cmd, "DIS") == 0)
{
    if (argA == NULL)
    {
        Serial.println(F("ERR: DIS requires record number"));
        return;
    }

    // -----------------------------
    // Get record number
    // -----------------------------
    char *endPtr;
    unsigned long recordNumber = strtoul(argA, &endPtr, 10);

    if (*endPtr != '\0')
    {
        Serial.println(F("ERR: invalid record number"));
        return;
    }

    const uint16_t recordCount =
        (MAX_ADDRESS + 1UL) / sizeof(CallRecord);

    if (recordNumber >= recordCount)
    {
        Serial.println(F("ERR: record number out of range"));
        return;
    }

    // -----------------------------
    // Read record
    // -----------------------------
    CallRecord record;
    CallData data;

    readRecord((uint16_t)recordNumber, record);

    // Convert fixed EEPROM record to
    // null-terminated CallData
    recordToCallData(record, data);

    // -----------------------------
    // Display record
    // -----------------------------
    Serial.println();
    Serial.print(F("RECORD:    "));
    Serial.println(recordNumber);

    Serial.print(F("Name:      "));
    Serial.println(data.name);

    Serial.print(F("Number:    "));
    Serial.println(data.number);

    Serial.print(F("Date:      "));
    Serial.println(data.date);

    Serial.print(F("Count:     "));
    Serial.println(data.count);

    Serial.print(F("Type:      "));
    Serial.println(data.type);

    Serial.print(F("Partial:   "));
    Serial.println(data.duplicate);

    Serial.println();

    return;
}





// ========================================
// LST
// Display every non-empty record
// ========================================

if (strcmp(cmd, "LST") == 0)
{
    const uint16_t recordCount =
        (MAX_ADDRESS + 1UL) / sizeof(CallRecord);

    uint16_t listedCount = 0;

    CallRecord record;
    CallData data;

    Serial.println();
    Serial.println(F("----- NON-EMPTY RECORDS -----"));

    for (uint16_t recordNumber = 0;
         recordNumber < recordCount;
         recordNumber++)
    {
        readRecord(recordNumber, record);

        if (record.type == 'E')
            continue;

        recordToCallData(record, data);

        Serial.print(F("REC "));
        Serial.print(recordNumber);

        Serial.print(F("  TYPE:"));
        Serial.print(data.type);

        Serial.print(F("  NAME:"));
        Serial.print(data.name);

        Serial.print(F("  NUM:"));
        Serial.print(data.number);

        Serial.print(F("  DATE:"));
        Serial.print(data.date);

        Serial.print(F("  COUNT:"));
        Serial.print(data.count);

        Serial.print(F("  DUP:"));
        Serial.println(data.duplicate);

        listedCount++;
    }

    Serial.print(F("RECORDS LISTED: "));
    Serial.println(listedCount);
    Serial.println(F("-----------------------------"));

    return;
}

//  enter new command below this line



// add commands above here

    // ========================================
    // Unknown command
    // ========================================

    Serial.print(F("ERR: unknown command "));
    Serial.println(cmd);
}



// ----------------------------------------------------
// Initialize serial communications
// ----------------------------------------------------

void c_serial_begin()
{
    Serial.begin(SERIAL_BAUD);

    serialIndex = 0;

    Serial.println(F("Call Blocker Serial Ready"));
}


// ----------------------------------------------------
// Check for serial input
//
// Call this repeatedly from loop()
// ----------------------------------------------------

void check_c_serial()
{
    while (Serial.available() > 0)
    {
        char c = Serial.read();


        // ----------------------------------------
        // End of command
        //
        // Accept CR, LF, or CR/LF from Serial Monitor
        // ----------------------------------------

        if (c == '\r' || c == '\n')
        {
            if (serialIndex > 0)
            {
                serialBuf[serialIndex] = '\0';

                process_serial_command(serialBuf);

                serialIndex = 0;
            }

            continue;
        }


        // ----------------------------------------
        // Add character to receive buffer
        // ----------------------------------------

        if (serialIndex < SERIAL_BUF_SIZE - 1)
        {
            serialBuf[serialIndex++] = c;
        }
        else
        {
            serialIndex = 0;

            Serial.println(F("ERR: command too long"));
        }
    }
}
